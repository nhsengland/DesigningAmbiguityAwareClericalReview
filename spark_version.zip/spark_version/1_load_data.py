# scripts/1_load_data.py
from daacr.spark_utils import get_spark, persist, read_parquet, write_parquet
from pyspark.sql import functions as F


def main(inp_path: str, out_path: str):
    spark = get_spark("DAACR_Load")
    df = read_parquet(spark, inp_path).withColumn("id", F.col("id").cast("string")).dropDuplicates()
    df = persist(df)
    write_parquet(df, out_path)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()
    main(args.inp, args.out)

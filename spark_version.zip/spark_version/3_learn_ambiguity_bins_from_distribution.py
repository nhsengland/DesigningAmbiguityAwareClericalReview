from pyspark.sql import DataFrame

def learn_bin_edges(df: DataFrame, col: str, bins: int, rel_err: float = 1e-3):
    probs = [i / bins for i in range(1, bins)]
    return df.approxQuantile(col, probs, rel_err)

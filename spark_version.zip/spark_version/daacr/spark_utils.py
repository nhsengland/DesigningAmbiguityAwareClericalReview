# src/daacr/spark_utils.py
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel


def get_spark(app_name: str = "DAACR", shuffle_partitions: int | None = 400) -> SparkSession:
    builder = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.execution.arrow.pyspark.enabled", "true")
    )
    if shuffle_partitions is not None:
        builder = builder.config("spark.sql.shuffle.partitions", str(shuffle_partitions))
    return builder.getOrCreate()

def read_parquet(spark: SparkSession, path: str) -> DataFrame:
    return spark.read.parquet(path)

def write_parquet(df: DataFrame, path: str, mode: str = "overwrite", partitionBy: list[str] | None = None) -> None:
    (df.write.mode(mode).partitionBy(*partitionBy) if partitionBy else df.write.mode(mode)).parquet(path)

def persist(df: DataFrame, level: StorageLevel = StorageLevel.MEMORY_AND_DISK) -> DataFrame:
    return df.persist(level)

def small_collect(df: DataFrame, max_rows: int = 100_000):
    # Safety: keep driver memory sane
    return df.limit(max_rows).toPandas()

def count_distinct_safe(df: DataFrame, *cols: str) -> DataFrame:
    return df.agg(*[F.countDistinct(F.col(c)).alias(f"n_distinct_{c}") for c in cols])

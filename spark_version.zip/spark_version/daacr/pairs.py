# src/daacr/pairs.py
from daacr.binning import add_quantile_bins, add_uncertainty
from pyspark.sql import DataFrame


def prepare_pairs_with_uncertainty_spark(
    df_pairs: DataFrame,
    score_col: str = "predicted_match_prob",
    ambiguity_col: str | None = "ambiguity_score",
    n_uncertainty_bins: int = 10,
    n_ambiguity_bins: int = 10,
) -> DataFrame:
    df = add_uncertainty(df_pairs, score_col, out_col="uncertainty")
    df = add_quantile_bins(df, "uncertainty", n_uncertainty_bins, "uncertainty_bin")
    if ambiguity_col:
        df = add_quantile_bins(df, ambiguity_col, n_ambiguity_bins, "ambiguity_bin")
    return df

# src/daacr/viz_bridge.py
from pyspark.sql import DataFrame
from pyspark.sql import functions as F


def agg_for_plot(df: DataFrame, group_cols: list[str], count_col: str = "n"):
    g = df.groupBy(*group_cols).count().withColumnRenamed("count", count_col)
    total = g.agg(F.sum(F.col(count_col)).alias("_tot")).collect()[0]["_tot"]
    return g.withColumn("share", F.col(count_col) / F.lit(total))

# src/daacr/binning.py
from pyspark.ml.feature import QuantileDiscretizer
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F


def add_uncertainty(df: DataFrame, score_col: str, out_col: str = "uncertainty") -> DataFrame:
    # Uncertainty peaks at 0.5, 0 at 0/1
    return df.withColumn(out_col, 1.0 - F.abs(F.col(score_col) - F.lit(0.5)) * 2.0)

def add_quantile_bins(
    df: DataFrame, col: str, bins: int, out_col: str, rel_err: float = 1e-3
) -> DataFrame:
    # Uses Spark’s approxQuantile via QuantileDiscretizer
    disc = (QuantileDiscretizer(numBuckets=bins, inputCol=col, outputCol=out_col, relativeError=rel_err, handleInvalid="keep"))
    model = disc.fit(df)
    return model.transform(df)

def sample_per_cell(
    df: DataFrame,
    bin_cols: list[str],
    n_per_cell: int,
    seed: int = 42,
) -> DataFrame:
    w = Window.partitionBy(*bin_cols).orderBy(F.rand(seed))
    return df.withColumn("__rn", F.row_number().over(w)).filter(F.col("__rn") <= n_per_cell).drop("__rn")

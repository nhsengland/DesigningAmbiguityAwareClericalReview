# scripts/5_draw_sample.py
from daacr.binning import sample_per_cell
from daacr.spark_utils import get_spark, read_parquet, write_parquet


def main(inp_path: str, out_path: str, n_per_cell: int, bin_cols: list[str]):
    spark = get_spark("DAACR_Draw_Sample")
    df = read_parquet(spark, inp_path)
    df = sample_per_cell(df, bin_cols=bin_cols, n_per_cell=n_per_cell, seed=42)
    write_parquet(df, out_path)

if __name__ == "__main__":
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--n-per-cell", type=int, default=50)
    ap.add_argument("--bin-cols", type=str, default='["uncertainty_bin","ambiguity_bin"]')
    args = ap.parse_args()
    main(args.inp, args.out, args.n_per_cell, list(json.loads(args.bin_cols)))

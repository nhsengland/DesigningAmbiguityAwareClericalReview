# scripts/2_matchability.py
from daacr.spark_utils import get_spark, read_parquet, write_parquet
from pyspark.sql import functions as F


def add_ambiguity(df, key_cols=("key1","key2")):
    amb = df.groupBy(*key_cols).agg(F.count("*").alias("cluster_size"))
    return df.join(amb, on=list(key_cols), how="left")

def main(inp_path: str, out_path: str, key_cols: list[str]):
    spark = get_spark("DAACR_Matchability")
    df = read_parquet(spark, inp_path)
    df = add_ambiguity(df, key_cols=tuple(key_cols))
    df = df.withColumn("ambiguity_score", F.when(F.col("cluster_size").isNull(), 1).otherwise(F.col("cluster_size")))
    write_parquet(df, out_path)

if __name__ == "__main__":
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--keys", type=str, required=True, help='JSON list of key columns')
    args = ap.parse_args()
    main(args.inp, args.out, key_cols=list(json.loads(args.keys)))

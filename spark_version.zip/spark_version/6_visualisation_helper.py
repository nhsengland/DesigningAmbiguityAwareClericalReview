# scripts/6_visualisation_helper.py
from daacr.spark_utils import get_spark, read_parquet, small_collect
from daacr.viz_bridge import agg_for_plot


def main(inp_path: str, out_csv: str):
    spark = get_spark("DAACR_Viz")
    df = read_parquet(spark, inp_path)
    plot_df = agg_for_plot(df, group_cols=["uncertainty_bin","ambiguity_bin"])
    pdf = small_collect(plot_df, max_rows=10_000)
    pdf.to_csv(out_csv, index=False)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out-csv", dest="out_csv", required=True)
    args = ap.parse_args()
    main(args.inp, args.out_csv)

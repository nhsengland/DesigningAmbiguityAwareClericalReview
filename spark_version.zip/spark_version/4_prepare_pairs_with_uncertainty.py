# scripts/prepare_pairs_with_uncertainty.py
from daacr.pairs import prepare_pairs_with_uncertainty_spark
from daacr.spark_utils import get_spark, read_parquet, write_parquet


def main(inp_path: str, out_path: str, score_col: str, ambiguity_col: str | None, ub: int, ab: int):
    spark = get_spark("DAACR_Pairs_Uncertainty")
    df = read_parquet(spark, inp_path)
    df = prepare_pairs_with_uncertainty_spark(df, score_col, ambiguity_col, ub, ab)
    write_parquet(df, out_path)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--score-col", default="predicted_match_prob")
    ap.add_argument("--ambiguity-col", default="ambiguity_score")
    ap.add_argument("--uncertainty-bins", type=int, default=10)
    ap.add_argument("--ambiguity-bins", type=int, default=10)
    args = ap.parse_args()
    amb_col = None if args.ambiguity_col.lower() in {"", "none"} else args.ambiguity_col
    main(args.inp, args.out, args.score_col, amb_col, args.uncertainty_bins, args.ambiguity_bins)
